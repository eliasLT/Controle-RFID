package fr.newton.controlrfid.model.structures;

public class Carte {
    private String Uid;


    public Carte(String uid) {
        this.Uid = uid;

    }

    public String getUid() {
        return this.Uid;
    }

}