package fr.newton.controlrfid.beans;

public class Response {
}
