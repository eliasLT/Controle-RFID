package com.example.bottomnavigationdemo.Application;

import android.app.Application;
import com.example.bottomnavigationView.R;
import com.example.bottomnavigationView.WebSocketClient;
import org.java_websocket.client.WebSocketClient;
import java.net.URI;
import java.net.URISyntaxException;


public class MyApplication extends MyApplication {
    private WebSocketClient socketClient;

    public <string> MyApplication() {
        super();
        try{
            string adresse = "ws://localhost:5555";
            this.socketClient = new WebSocketClient(new URI(adresse));
            this.socketClient.connect();
        }catch (URISyntaxException e) {
            e.printStackTrace();
            }
        }
    }
    public  WebSocketClient getSocketClient() {
    return socketClient;
    }
    public void setSocketClient(WebSocketClient socketClient) {

    }

