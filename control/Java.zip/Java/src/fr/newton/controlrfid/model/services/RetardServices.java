package fr.newton.controlrfid.model.services;

import fr.newton.controlrfid.model.structures.Eleve;

import java.util.ArrayList;

public class RetardServices {
    public static void registerLateStudents(ArrayList<Eleve> lateStudents) {

    }
}
